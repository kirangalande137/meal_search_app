export default {
  searchedMeals: [],
  mealsByLetter: [],
  mealsByIngredient: [],
  ingredient: {}
}